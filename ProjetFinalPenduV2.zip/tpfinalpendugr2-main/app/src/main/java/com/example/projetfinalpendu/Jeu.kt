package com.example.projetfinalpendu

class Jeu(var listeMots : ArrayList<String> ) {
    var pointage : Int = 0
    var nbErreurs : Int = 0
    var motADeviner : String = ""

 fun essayerUneLettre(lettre : Char) : MutableList<Int> {
     var occurence = mutableListOf<Int>()
     var position : Int
     if(listeMots.contains(lettre)) {
         position = listeMots.indexOf(lettre)
         occurence.add(position)
         pointage++
     } else {nbErreurs ++}
     return occurence
 }

}
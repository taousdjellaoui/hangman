import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.example.projetfinalpendu.Word

class WordDAO(context: Context, dbName: String, dbVersion: Int) {

    private val dbHelper = WordDatabaseHelper(context)

    fun insertWord(word : Word) {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(WordDatabaseHelper.COLUMN_LANGUAGE, word.language)
            put(WordDatabaseHelper.COLUMN_WORD, word.word)
            put(WordDatabaseHelper.COLUMN_WORD, word.nvDiff)
        }
        db.insert(WordDatabaseHelper.TABLE_NAME, null, values)
        db.close()
    }

    fun getAllWords(language: String): List<Word> {
        val wordList = mutableListOf<Word>()
        val db = dbHelper.readableDatabase
        val query = "SELECT * FROM ${WordDatabaseHelper.TABLE_NAME} WHERE ${WordDatabaseHelper.COLUMN_LANGUAGE} = ?"
        val cursor: Cursor = db.rawQuery(query, arrayOf(language))
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndex(WordDatabaseHelper.COLUMN_ID))
                val word = cursor.getString(cursor.getColumnIndex(WordDatabaseHelper.COLUMN_WORD))
                val nvDIFF = cursor.getString(cursor.getColumnIndex(WordDatabaseHelper.COLUMN_NIVDIFF))
                wordList.add(Word(id, language, word, nvDIFF))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return wordList
    }

    fun deleteAllWords() {
        val db = dbHelper.writableDatabase
        db.delete(WordDatabaseHelper.TABLE_NAME, null, null)
        db.close()
    }
}

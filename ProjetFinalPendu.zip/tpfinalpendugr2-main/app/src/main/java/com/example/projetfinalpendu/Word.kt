package com.example.projetfinalpendu

data class Word(val id: Int, val language: String, val word: String)
